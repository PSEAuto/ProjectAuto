package autos;

import java.io.InputStream;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.enterprise.context.SessionScoped;
import javax.faces.event.ActionEvent;
import javax.inject.Named;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

@Named
@SessionScoped
public class Liste implements Serializable {
	private static final long serialVersionUID = 1L;
	private String preis;
	private String marke;
	private double kmStand;
	private int erstzulassung;
	private String modell;
	private String stadt;
	private String kraftstoff;
	private String getriebe;
	private String karosserieform;
	private double ps;
	private int id;

	ArrayList<Auto> autos = new ArrayList<Auto>();
	private DataModel dm = null;

	public Liste() {

		autos = new ArrayList<Auto>();
		dm = new DataModel(autos);
	}

	/*--------------------------------------------------------------------------*/
	Auto aktuellesAuto = new Auto("Preis", 0, "Marke", 0, "Modell", "Stadt", "Kraftstoff", "Getriebe", "KarosserieForm",
			0.0, 0.0);

	public void setAktuellesAuto(Auto aktuelleAuto) {
		this.aktuellesAuto = aktuelleAuto;
	}

	/**
	 * Die Methode gibt die aktuelleImmobilie zurück, die dann auf der zweiten
	 * Seite separat angezeigt wird mit den einzelnen Daten zur Immobilie. *
	 * 
	 * @return
	 */
	public Auto getAktuelleImmobilie() {

		for (int i = 0; i < autos.size(); i++) {
			System.out.println(autos.get(i).toString());
			if (id == autos.get(i).getId()) {
				System.out.println("gefunden");
				aktuellesAuto = autos.get(i);
				break;
			}
		}
		return aktuellesAuto;
	}

	/**
	 * Die Methode search gibt je nach Angabe der Informationen, die passende
	 * Immobiilie zurück aus der Datenbank. *
	 * 
	 * @param ae
	 */
	public void search(ActionEvent ae) {
		autos.clear();
		System.out.println("search anfang");
		final String sql = "select * from AutoDatenbank where Preis<=? and Marke=? and erstzulassung >=? and modell=? and stadt =? and kraftstoff = ? and getriebe =? and karosserieform =? and kilometerstand between ? and ? and ps>=?";
		Util util = new Util();

		Connection con = util.getCon();
		ResultSet rs = null;
		PreparedStatement pst = null;
		try {
			pst.getConnection().prepareStatement(sql);
			pst.executeQuery();
			rs = pst.getResultSet();

			while (rs.next()) {
				// Daten im Objekt speichern
				pst.setString(1, preis);
				pst.setInt(2, id);
				pst.setString(3, marke);
				pst.setInt(4, erstzulassung);
				pst.setString(5, modell);
				pst.setString(6, stadt);
				pst.setString(7, kraftstoff);
				pst.setString(8, getriebe);
				pst.setString(9, karosserieform);
				pst.setDouble(10, kmStand);
				pst.setDouble(11, ps);

				Auto a = new Auto(rs.getString(1), rs.getInt(2), rs.getString(3), rs.getInt(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getDouble(10),
						rs.getDouble(11));

				autos.add(a);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public boolean save(Auto a) {
		String sql = "insert into Autodatenbank (Autoid, Preis, Marke, erstzulassung, Modell, Stadt, kraftstoff, getriebe, Karosserieform, Kilometerstand, ps) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
		Util util = new Util();
		Connection con = util.getCon();
		try {
			con.setAutoCommit(false);
			PreparedStatement pst = con.prepareStatement(sql, new String[] { "Autoid" });
			pst.setString(1, a.getPreis());

			pst.setString(2, a.getMarke());
			pst.setInt(3, a.getErstezulassung());
			pst.setString(4, a.getModell());
			pst.setString(5, a.getStadt());
			pst.setString(6, a.getKraftstoff());
			pst.setString(7, a.getGetriebe());
			pst.setString(8, a.getKarosserieform());
			pst.setDouble(9, a.getKmStand());
			pst.setDouble(10, a.getPs());

			int affectedRows = pst.executeUpdate();
			if (affectedRows == 0)
				throw new SQLException("Hat nicht geklappt");
			int a_id = this.getGeneratedKey(pst);
			a.setId(a_id);
			con.commit();
			con.setAutoCommit(true);

			pst.close();
			return true;

		} catch (SQLException e) {
			try {
				con.rollback();
				con.setAutoCommit(true);
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return false;

	}

	/*--------------------------------------------------------------------------*/ Util util = new Util();
	private StreamedContent streamedPic = null;

	final String PIC_TEXT_JA = "And this is the picture:";
	final String PIC_TEXT_NEIN = "";
	private String picText = PIC_TEXT_NEIN;
	final String CLASSNAME = getClass().getName();

	public String getPicText() {
		return picText;
	}

	/**
	 * Die Methode getStreamedPic() holt das Bild aus der Datenbank und gibt es *
	 * zurück.
	 *
	 * @return
	 */
	public StreamedContent getStreamedPic() {
		System.out.println(CLASSNAME + ".getStreamedPic()...");

		getPic();
		return streamedPic;
	}

	public void getPic() {
		System.out.println(CLASSNAME + ".getPic()...");
		String typ = "?";
		Connection con = util.getCon();
		if (con != null) {
			try {
				PreparedStatement ps = con.prepareStatement("SELECT Foto FROM AutoDatenbank WHERE Id=?");
				ps.setInt(1, id);
				ResultSet rs = ps.executeQuery();
				if (rs.next()) {
					InputStream is = rs.getBinaryStream(1);
					streamedPic = new DefaultStreamedContent(is, typ);
					is.close();
					picText = PIC_TEXT_JA;
				} else
					System.err.println("ResultSet ist leer!!");
				rs.close();
				ps.close();
				con.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		} else
			System.err.println("Connection ist null!!");
	}

	public DataModel getImmobilien() {
		if (autos != null) {
			System.out.println(autos.size());
		} else
			System.out.println("Autoist null");
		return dm;
	}

	private int getGeneratedKey(PreparedStatement pst) {
		try {
			ResultSet rs = pst.getGeneratedKeys();

			if (rs.next()) {
				int key = rs.getInt(1);
				if (rs.next())
					throw new SQLException("More than one key generated");
				return key;
			} else {
				throw new SQLException("No Key generated.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return -1;
	}

}
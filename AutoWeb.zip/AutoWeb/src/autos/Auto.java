package autos;

import com.mysql.jdbc.Blob;


public class Auto {
	
	//Instanzvariabel

	private String preis = "Preis";
	private int id = 0;
	private String marke = "Marke";
	private int erstezulassung = 0;
	private String modell = "Modell";
	private String stadt = "Stadt";
	private String kraftstoff = "Kraftstoff";
	private String getriebe = "Getriebe";
	private String karosserieform = "Karosserieform";
	private double kmStand = 0.0;
	private double ps = 0.0;
	private java.sql.Blob foto;

	
	//konstruktor
	public Auto(String preis, int id, String marke, int erstezulassung, String modell, String stadt, String kraftstoff,
			String getriebe, String karosserieform, double kmStand, double ps) {
		super();
		this.preis = preis;
		this.id = id;
		this.marke = marke;
		this.erstezulassung = erstezulassung;
		this.modell = modell;
		this.stadt = stadt;
		this.kraftstoff = kraftstoff;
		this.getriebe = getriebe;
		this.karosserieform = karosserieform;
		this.kmStand = kmStand;
		this.ps = ps;
	}
 
	public Auto() {
		System.out.println("Konstruktor");
	}
	//getter und setter Methoden

	public java.sql.Blob getFoto() {
		System.out.println("getblob");
		return foto;
	}

	public void setFoto(Blob foto) {
		this.foto = foto;
	}

	public String getPreis() {
		return preis;
	}

	public void setPreis(String preis) {
		this.preis = preis;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMarke() {
		return marke;
	}

	public void setMarke(String marke) {
		this.marke = marke;
	}

	public int getErstezulassung() {
		return erstezulassung;
	}

	public void setErstezulassung(int erstezulassung) {
		this.erstezulassung = erstezulassung;
	}

	public String getModell() {
		return modell;
	}

	public void setModell(String model) {
		this.modell = model;
	}

	public String getStadt() {
		return stadt;
	}

	public void setStadt(String stadt) {
		this.stadt = stadt;
	}

	public String getKraftstoff() {
		return kraftstoff;
	}

	public void setKraftstoff(String kraftstoff) {
		this.kraftstoff = kraftstoff;
	}

	public String getGetriebe() {
		return getriebe;
	}

	public void setGetriebe(String getriebe) {
		this.getriebe = getriebe;
	}

	public String getKarosserieform() {
		return karosserieform;
	}

	public void setKarosserieform(String karosserieform) {
		this.karosserieform = karosserieform;
	}

	public double getKmStand() {
		return kmStand;
	}

	public void setKmStand(double kmStand) {
		this.kmStand = kmStand;
	}

	public double getPs() {
		return ps;
	}

	public void setPs(double ps) {
		this.ps = ps;
	}

}
